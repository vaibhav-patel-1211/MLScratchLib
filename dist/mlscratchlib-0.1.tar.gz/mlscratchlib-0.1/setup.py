from setuptools import setup, find_packages

setup(
    name="mlscratchlib",
    version="0.1",
    packages=find_packages(),
    author='PATEL VAIBHAV',
    author_email='vaibhav1211patel@gmail.com',
    install_requires=[
        'numpy',
        'matplotlib'
    ]
)